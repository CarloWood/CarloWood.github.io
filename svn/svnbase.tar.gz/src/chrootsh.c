/*
 * Chroots to a pre-defined location and executes svnserv
 *
 * Since chrootsh will be called from outside the chroot jail, it does not need
 * to be statically linked
 *
 * Copyright (c) 2004 David Shea
 * Copyright (c) 2006 Carlo Wood
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * 10 Nov 2006
 * 	A completely "rewritten" version by Carlo Wood to harden security,
 * 	heavily	based on chroot.{ch} of chrootutils-0.4.tar.gz by David Shea.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/resource.h>

/* Command structure */
struct command {
   char const* cmd;		/* The full command as a string, as it would be passed to sh -c; i.e. "svnserve -t". */
   char const* const* args;	/* NULL terminated array of arguments, as it would be passed to execv;
                                   i.e. { "/bin/svnserve", "-t", NULL }. */
};

#ifndef PROJECT
#error PROJECT is not defined
#endif
#ifndef SVNBASE
#error SVNBASE is not defined
#endif

/* The path passed to the chroot call; the base of the root jail. */
#define CHROOT_DIR SVNBASE "/" PROJECT "/root"

/*
 * Both must be string literals. For example:
 * g++ -O2 -DSVNBASE='"/opt/svn"' -DPROJECT='"test"' -o chrootsh chrootsh.c
 * Note the use of single and double quotes.
 */
static char const* svnbase = SVNBASE;	/* See http://www.xs4all.nl/~carlo17/svn/ */
static char const* project = PROJECT;	/* The name of the project. Should not contain '/'. */

/*
 * Put all the macros in the first section (to make it near
 * impossible to exploit them in the case someone manages
 * to get them defined in an arbitrary way).
 */
static char const* error1 = "Unable to chdir to " CHROOT_DIR;
static char const* error2 = "Unable to chroot to " CHROOT_DIR;
static char const* errorh = "Could not chdir to $HOME (relative to jail root " CHROOT_DIR ")";

/* For sanity testing */
static size_t const sizeof_CHROOT_DIR = sizeof(CHROOT_DIR);
static char last_char(void) { return (((char*)CHROOT_DIR)[sizeof_CHROOT_DIR - 1]); }

/* The jail root. */
static char const* chroot_dir = CHROOT_DIR;

/* The value of PATH in the new environment. */
static char const* chroot_path = "/bin";

/* The allowed commands in the jail root. */
static char const* arg_list0[] = { "/bin/cvs", "server", NULL };
static char const* arg_list1[] = { "/bin/svnserve", "-t", NULL };

/*
 * Initialize a static array with allowed commands.
 */
static struct command allowed_commands[] = {
  { "cvs server", arg_list0 },
  { "svnserve -t", arg_list1 },
  { "test", NULL }
};

/*
 * Maximum size of the data segment. Can be RLIM_INFINITY for no limit.
 * Undefine to just skip the ulimit call entirely. Default is 32MB.
 */
#define DATA_LIMIT (32 * (1048576L))

/*
 * Although CHROOT_DIR is hardcoded, perform some tests anyway.
 * Security note: This function is called as root. Although it
 * MIGHT be possible to exploit it if an attacker would be
 * able to define CHROOT_DIR in an arbitrary way; it is extremely
 * unlikely that anyone who doesn't have root can do so AND
 * get the result installed setuid root. It is more likely that
 * the whole file will be changed in that case ;)
 * So, this function is merely here to catch accidently made mistakes.
 */
static void sanity_checks(void)
{
  size_t len;
  int i;
  int error = 0;

  do
  {
    if (sizeof_CHROOT_DIR > 64 || sizeof_CHROOT_DIR == 0)
    {
      error = 1;	/* Not a string literal, or string literal too long. */
      break;
    }
    if (last_char() != 0)
    {
      error = 1;	/* Not a string literal. */
      break;
    }
    len = strlen(chroot_dir);
    if (sizeof_CHROOT_DIR != len + 1)
    {
      error = 2;	/* String literal contains zeros. */
      break;
    }
    for (i = 0; i < len; ++i)
    {
      if (chroot_dir[i] != '/' && !isalnum(chroot_dir[i]) &&
          chroot_dir[i] != '-' && chroot_dir[i] != '_' && chroot_dir[i] != '.')
      {
	error = 3;	/* String literal contains weird characters. */
	break;
      }
    }
    if (error)
      break;
    if (chroot_dir[0] != '/')
    {
      error = 5;	/* SVNBASE is not an absolute path. */
      break;
    }
    /* If we get here then len > 0. */
    if (chroot_dir[len - 1] == '/')
    {
      error = 6;	/* PROJECT ends on '/'? */
      break;
    }
  }
  while(0);
  if (error)
  {
    fprintf(stderr, "CHROOT_DIR format error %d\n", error);
    exit(EXIT_FAILURE);
  }
}

/*
 * Don't allow an interactive shell at all, only allow certain commands.
 * Things that need to be done:
 *      - chdir, chroot
 *      - drop root privileges (suid in order to chroot)
 *      - process arguments (need a -c, throw away everything else)
 *      - set $PATH, $HOME, $SHELL
 *      - set limits
 *      - chdir to $HOME
 *      - exec the command
 */
int main(int argc, char* argv[])
{
  int i;
  char* home;
  char* command_str;
  struct command* cmd;
  struct rlimit limit;
  int saved_errno;
  int error = 0;		/* No error by default */

  /* Make sure chroot_dir is what we expect. */
  sanity_checks();

  /* First things first: try to drop privs! */
  do	/* So that we can use 'break' */
  {
    if (chdir(chroot_dir))
    {
      saved_errno = errno;
      error = 1;
      break;
    }
    if (chroot("."))
    {
      saved_errno = errno;
      error = 2;
      break;
    }
    if (setuid(getuid()))
    {
      saved_errno = errno;
      error = 3;
      break;
    }
    /* home should be set to $HOME minus chroot_dir. */
    if ((home = getenv("HOME")) == NULL ||
	 strncmp(home, chroot_dir, (i = strlen(chroot_dir))) != 0 ||
	 *(home += i) != '/')
    {
      saved_errno = errno;
      error = -1;
      break;
    }
    if (setenv("PATH", chroot_path, 1) == -1 ||
	setenv("HOME", home, 1) == -1 ||
	setenv("SHELL", "/bin/sh", 1) == -1 ||
	setenv("LANG", "C", 1) == -1)	/* Set this, so we don't need the locale files in the jail root. */
    {
      saved_errno = errno;
      error = -2;
      break;
    }
  }
  while(0);

  /*
   * If 'error' is larger than zero here, we are still root.
   * Don't print any information about the error however
   * unless the the whole command looks sane (that is,
   * it is a real attempt to acces the repository).
   */
  if (*(argv[0]) == '-')
  {
    /* Don't call fprintf as root. */
    if (error <= 0)
      fprintf(stderr, "\nError: %s cannot be run as a login shell\n", argv[0] + 1);
    exit(EXIT_FAILURE);
  }
  if (argc < 3)
  {
    /* Don't call fprintf as root. */
    if (!error)
      fprintf(stderr, "\nError: %s: Not enough arguments\n", argv[0]);
    exit(EXIT_SUCCESS);
  }
  /*
   * POSIX is fairly unclear on -c interpretation, and no one implements
   * like they specify (i.e., 'sh -c command foo bar baz' will be 
   * executed as $0=command, $1 unset, instead of $0=foo, $1=bar, &c),
   * so just going with tradition on this one.
   */
  opterr = 0;
  command_str = NULL;
  while ((i = getopt(argc, argv, "c:")) != -1)
  {
    if (i == 'c')
      command_str = optarg;
    else
    {
      char c = i;
      /* Don't call fprintf as root or when it's a clear exploit attempt. */
      if (error <= 0 && isprint(c))
	fprintf(stderr, "Option -%c not supported\n", c);
      exit(EXIT_FAILURE);
    }
  }
  if (command_str == NULL)
  {
    /* Don't call fputs as root. */
    if (error <= 0)
      fputs("Command must be given with -c\n", stderr);
    exit(EXIT_FAILURE);
  } 

  /* Only allow commands in the allowed_cmds array. */
  cmd = NULL;
  for (i = 0; i < sizeof(allowed_commands) / sizeof(allowed_commands[0]); ++i)
  {
    if (strcmp(command_str, allowed_commands[i].cmd) == 0)
    {
      cmd = &allowed_commands[i];
      break;
    }
  }
  if (cmd == NULL)
  {
    /* Don't call fprintf as root */
    if (error <= 0)
      fprintf(stderr, "Command '%s' not supported. Try 'test' instead.\n", command_str);
    exit(EXIT_FAILURE);
  }
  if (error)
  {
    errno = saved_errno;
    if (error == 1)
      perror(error1);
    if (error == 2)
      perror(error2);
    if (error == 3)
      perror("Unable to set effective UID");
    if (error == -1)
      fprintf(stderr,
	  "Invalid setting for $HOME: \"%s\" (CHROOT_DIR = \"%s\")\n",
	  home ? home : "(null)", chroot_dir);
    if (error == -2)
      perror("Error setting up environment");
    exit(EXIT_FAILURE);
  }

  /* Change to home directory. */
  if (chdir(home))
  {
    perror(errorh);
    exit(EXIT_FAILURE);
  }

  if (cmd->args == NULL)
  {
    fputs("This worked. Now try svn.\n", stderr);
    exit(EXIT_FAILURE);
  }

  /* Disable dumping core. */
  limit.rlim_cur = 0;
  limit.rlim_max = 0;
  setrlimit(RLIMIT_CORE, &limit);

  /* Set limit on data segment if desired. */
#ifdef DATA_LIMIT
  limit.rlim_cur = DATA_LIMIT;
  limit.rlim_max = DATA_LIMIT;
  setrlimit(RLIMIT_DATA, &limit);
#endif

  /* Run the fixed command. */
  execv(cmd->args[0], (char* const*)cmd->args);
  perror(cmd->args[0]);
  exit(EXIT_FAILURE);
}
